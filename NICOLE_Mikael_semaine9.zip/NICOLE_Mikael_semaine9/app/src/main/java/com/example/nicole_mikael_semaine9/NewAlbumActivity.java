package com.example.nicole_mikael_semaine9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class NewAlbumActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_album);
//        String data = getIntent().getStringExtra("data");
//        Log.i("data", data);
//        //        TextView textView = findViewById(R.id.textViewData);
//        TextView textView = findViewById(R.id.txtVTitre);
//        textView.setText(data);
    }
}